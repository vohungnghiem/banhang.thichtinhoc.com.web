<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Congno extends Model
{
    use HasFactory;
    protected $table = "vhn_congnos";
    public $timestamps = false;
}
